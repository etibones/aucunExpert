create view v_ville as
  SELECT ville.id_ville,
    ville.libelle_ville
   FROM projets3.ville;

