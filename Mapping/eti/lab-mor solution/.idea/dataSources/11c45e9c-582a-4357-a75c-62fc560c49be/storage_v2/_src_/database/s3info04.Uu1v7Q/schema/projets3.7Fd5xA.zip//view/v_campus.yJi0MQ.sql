create view v_campus as
  SELECT campus.id_campus,
    campus.nom_campus
   FROM projets3.campus;

