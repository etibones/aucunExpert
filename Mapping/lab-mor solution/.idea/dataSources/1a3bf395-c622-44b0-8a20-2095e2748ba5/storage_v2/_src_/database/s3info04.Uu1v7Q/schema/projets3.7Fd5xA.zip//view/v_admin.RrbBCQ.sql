create view v_admin as
  SELECT privileges.id_privilege,
    privileges.libelle_privilege
   FROM projets3.privileges;

-- No source code for s3info04.projets3.v_admin.vue
;

