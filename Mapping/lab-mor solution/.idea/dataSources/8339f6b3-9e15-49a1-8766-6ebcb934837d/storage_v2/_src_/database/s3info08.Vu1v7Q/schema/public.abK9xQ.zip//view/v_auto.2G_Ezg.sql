create view v_auto as
  SELECT automobiles.cip,
    automobiles.nom_car,
    automobiles.annee_car,
    automobiles.marque
   FROM projets3.automobiles;

-- No source code for s3info08.public.v_auto.auto
;

