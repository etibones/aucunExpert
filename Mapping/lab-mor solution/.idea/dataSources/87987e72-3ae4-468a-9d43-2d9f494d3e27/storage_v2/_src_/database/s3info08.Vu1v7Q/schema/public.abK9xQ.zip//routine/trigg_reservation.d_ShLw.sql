create function trigg_reservation()
  returns trigger
language plpgsql
as $$
BEGIN
  insert INTO projets3.reserver(off_cip, nom_car, id_ville, id_campus, id_offre, cip)
  VALUES (1,'test',1,1,1,'drog2805');
  RETURN NEW;
END;
$$;

