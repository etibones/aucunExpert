create view v_auto as
  SELECT automobiles.nom_car,
    automobiles.annee_car,
    automobiles.marque
   FROM projets3.automobiles;

