create view v_privilege as
  SELECT privileges.id_privilege,
    privileges.libelle_privilege
   FROM projets3.privileges;

