create function fusion_reserver5()
  returns TABLE(nom text, prenom text, ville text, nomauto text)
language sql
as $$
SELECT c1.nom_usager,c1.prenom_usager,c4.libelle_ville, c3.nom_car from projets3.usagers as c1
  JOIN projets3.offres as c2
    on c1.cip = c2.cip
  join projets3.automobiles as c3
    on c3.nom_car = c2.nom_car
  join projets3.ville as c4
    on c2.id_ville = c4.id_ville
  join projets3.campus as c5
    on c2.id_campus = c5.id_campus;
$$;

