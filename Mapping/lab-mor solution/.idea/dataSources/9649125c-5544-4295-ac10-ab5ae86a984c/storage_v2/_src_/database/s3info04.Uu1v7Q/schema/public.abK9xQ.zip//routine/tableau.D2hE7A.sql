create function tableau(integer)
  returns TABLE(period time without time zone, id_locaux text, is_reserve boolean)
language sql
as $$
SELECT c1.horairedebut_categorie +  generate_series(0, EXTRACT (EPOCH from(horairefin_categorie - horairedebut_categorie)/(60*15))::INTEGER)* '15 minutes'::interval as period,
  c2.id_locaux,
  NULL::BOOLEAN as is_reserve
from app1.categories as c1
  CROSS JOIN app1.locaux as c2
  where c2.id_categorie = $1
  UNION
    select generate_series(heure_reservation_debut, heure_reservation_fin, '15 minutes'::interval)::TIME,
      hello.id_locaux,
      TRUE ::BOOLEAN as is_reserve
  from app1.reservations as hello
  JOIN app1.locaux as c1
    on c1.id_locaux = hello.id_locaux
  where c1.id_categorie = $1
  EXCEPT
  select generate_series(heure_reservation_debut, heure_reservation_fin, '15 minutes'::interval)::TIME,
  hello.id_locaux,
  NULL::BOOLEAN as is_reserve
from app1.reservations as hello
  JOIN app1.locaux as c1
    on c1.id_locaux = hello.id_locaux
where c1.id_categorie = $1;
$$;

