CREATE VIEW v_etudiant_app AS SELECT etudiant_app.etudiant_app_id,
    etudiant_app.cip,
    etudiant_app.nom,
    etudiant_app.courriel,
    etudiant_app.programme,
    etudiant_app.programme_nom,
    etudiant_app.app,
    etudiant_app.app_titre,
    etudiant_app.ap,
    etudiant_app.departement,
    etudiant_app.faculte,
    etudiant_app.universite
   FROM app.etudiant_app;
CREATE RULE upd_etudiant_app AS
    ON UPDATE TO app.v_etudiant_app DO INSTEAD  UPDATE app.etudiant_app SET cip = new.cip, nom = new.nom, courriel = new.courriel, programme = new.programme, programme_nom = new.programme_nom, app = new.app, app_titre = new.app_titre, ap = new.ap, departement = new.departement, faculte = new.faculte, universite = new.universite
  WHERE (etudiant_app.etudiant_app_id = new.etudiant_app_id);
;
CREATE RULE ins_etudiant_app AS
    ON INSERT TO app.v_etudiant_app DO INSTEAD  INSERT INTO app.etudiant_app (etudiant_app_id, cip, nom, courriel, programme, programme_nom, app, app_titre, ap, departement, faculte, universite)
  VALUES (new.etudiant_app_id, new.cip, new.nom, new.courriel, new.programme, new.programme_nom, new.app, new.app_titre, new.ap, new.departement, new.faculte, new.universite);
;
