CREATE RULE del_etudiant_app AS
    ON UPDATE TO app.v_etudiant_app DO INSTEAD  DELETE FROM app.etudiant_app
  WHERE (etudiant_app.etudiant_app_id = old.etudiant_app_id);