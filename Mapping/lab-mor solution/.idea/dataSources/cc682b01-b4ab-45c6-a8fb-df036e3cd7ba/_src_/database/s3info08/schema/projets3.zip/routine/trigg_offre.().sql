create function projets3.trigg_offre() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  insert INTO projets3.log (id_evenement,cip, description )
  VALUES (1,new.cip,'offre');
  RETURN NEW;
END;
$$;
