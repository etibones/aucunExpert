CREATE VIEW v_auto AS SELECT automobiles.cip,
    automobiles.nom_car,
    automobiles.annee_car,
    automobiles.marque
   FROM projets3.automobiles;
CREATE RULE auto AS
    ON INSERT TO public.v_auto DO INSTEAD  INSERT INTO projets3.automobiles (cip, nom_car, annee_car, marque)
  VALUES (new.cip, new.nom_car, new.annee_car, new.marque);
;
