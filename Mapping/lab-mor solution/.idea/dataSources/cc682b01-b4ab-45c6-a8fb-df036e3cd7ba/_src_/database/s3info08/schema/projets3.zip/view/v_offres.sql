CREATE VIEW v_offres AS SELECT fusion_offre.nom,
    fusion_offre.prenom,
    fusion_offre.ville,
    fusion_offre.libelle,
    fusion_offre.dateoffre,
    fusion_offre.nbplace,
    fusion_offre.bagage,
    fusion_offre.autonom,
    fusion_offre.autoannee
   FROM projets3.fusion_offre() fusion_offre(nom, prenom, ville, libelle, dateoffre, nbplace, bagage, autonom, autoannee);
