create view v_reserv as
  SELECT fusion_reserv.nom,
    fusion_reserv.prenom,
    fusion_reserv.couriel,
    fusion_reserv.date
   FROM projets3.fusion_reserv() fusion_reserv(nom, prenom, couriel, date);

