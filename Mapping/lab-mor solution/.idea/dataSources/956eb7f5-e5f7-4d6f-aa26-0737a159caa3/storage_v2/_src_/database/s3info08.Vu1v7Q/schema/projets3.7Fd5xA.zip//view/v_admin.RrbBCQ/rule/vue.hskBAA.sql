CREATE RULE vue AS
    ON INSERT TO projets3.v_admin DO INSTEAD  INSERT INTO projets3.privileges (id_privilege, libelle_privilege)
  VALUES (new.id_privilege, new.libelle_privilege);

