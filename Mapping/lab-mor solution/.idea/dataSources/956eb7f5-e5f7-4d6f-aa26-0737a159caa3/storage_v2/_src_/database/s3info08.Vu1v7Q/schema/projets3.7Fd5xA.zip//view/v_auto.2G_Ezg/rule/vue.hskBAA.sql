CREATE RULE vue AS
    ON INSERT TO projets3.v_auto DO INSTEAD  INSERT INTO projets3.automobiles (cip, nom_car, annee_car, marque)
  VALUES (new.cip, new.nom_car, new.annee_car, new.marque);

