create function trigg_offre()
  returns trigger
language plpgsql
as $$
BEGIN
  insert INTO projets3.log (id_evenement,cip, description )
  VALUES (1,new.cip,'offre');
  RETURN NEW;
END;
$$;

