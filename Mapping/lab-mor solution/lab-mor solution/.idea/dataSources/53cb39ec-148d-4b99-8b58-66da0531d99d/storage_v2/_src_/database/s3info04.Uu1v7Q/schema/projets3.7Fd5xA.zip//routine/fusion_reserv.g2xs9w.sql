create function fusion_reserv()
  returns TABLE(nom text, prenom text, couriel text, date date)
language sql
as $$
SELECT c1.nom_usager,c1.prenom_usager,c1.couriel,c2.date_reservation
from projets3.usagers as c1
  JOIN projets3.reserver as c2
    on c1.cip = c2.cip
$$;

