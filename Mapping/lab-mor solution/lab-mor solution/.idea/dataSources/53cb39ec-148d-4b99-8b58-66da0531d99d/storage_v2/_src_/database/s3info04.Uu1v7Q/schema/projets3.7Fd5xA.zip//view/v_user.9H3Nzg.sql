create view v_user as
  SELECT fusion_user_privilege.cip,
    fusion_user_privilege.nom,
    fusion_user_privilege.prenom,
    fusion_user_privilege.couriel,
    fusion_user_privilege.privilege
   FROM projets3.fusion_user_privilege() fusion_user_privilege(cip, nom, prenom, couriel, privilege);

