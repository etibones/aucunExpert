create function parent_enfant()
  returns trigger
language plpgsql
as $$
DECLARE
v_pere_id_locaux  text;
BEGIN
  SELECT id_locaux from app1.locaux as c1
    JOIN app1.locaux as c2
    on id_locaux = c2.pere_id_locaux
    INTO v_pere_id_locaux;
  INSERT INTO app1.reservations(cip, id_campus, id_pavillon, id_locaux, libelle_reservations, heure_reservation_debut, heure_reservation_fin)
  VALUES (new.cip, new.id_campus, new.id_pavillon, v_pere_id_locaux, new.libelle_reservations, new.heure_reservation_debut, new.heure_reservation_fin);
  return new;
END;
$$;

