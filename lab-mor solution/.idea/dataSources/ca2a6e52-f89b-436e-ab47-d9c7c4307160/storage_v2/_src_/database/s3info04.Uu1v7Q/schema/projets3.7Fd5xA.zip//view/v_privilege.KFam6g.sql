create view v_privilege as
  SELECT usagers.cip,
    usagers.id_privilege
   FROM projets3.usagers;

